const config = {
  "ownerID": "520119952850681858", //kendi IDınızı yazınız
  "admins": ["520119952850681858"],
  "support": ["520119952850681858"],
  "token": "NTIyMDA1NzU4NDAxODM5MTE2.Dw_AAg.XgDY10UClZE4sltHii5L0FwE-8g", //botunuzun tokenini yazınız
  "dashboard" : {
    "oauthSecret": "Im8Jq_m4SlSHwd191W2A_ickDXv-AEii", //botunuzun secretini yazınız 
    "callbackURL": `https://sonmez--tv.glitch.me/callback`,//site URLnizi yazınız /callback kısmını silmeyiniz!
    "sessionSecret": "xyzxyz", //kalsın
    "domain": "https://sonmez--tv.glitch.me/" //site URLnizi yazınız!
  }
};

module.exports = config;